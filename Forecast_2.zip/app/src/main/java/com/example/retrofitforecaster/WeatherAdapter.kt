package com.example.retrofitforecaster

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.retrofitforecaster.databinding.ListItemColdBinding
import com.example.retrofitforecaster.databinding.ListItemWarmBinding

class WeatherAdapter :
    ListAdapter<ListElement, WeatherAdapter.WeatherViewHolder>(WEATHER_COMPARISON) {

    companion object {
        private val WEATHER_COMPARISON = object : DiffUtil.ItemCallback<ListElement>() {
            override fun areItemsTheSame(oldItem: ListElement, newItem: ListElement): Boolean {
                return oldItem.dt == newItem.dt
            }

            override fun areContentsTheSame(oldItem: ListElement, newItem: ListElement): Boolean {
                return oldItem == newItem
            }
        }

        private const val TYPE_WARM = 1
        private const val TYPE_COLD = 2
    }

    override fun getItemViewType(position: Int): Int {
        return if (getItem(position).main.temp > 0) TYPE_WARM else TYPE_COLD
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeatherViewHolder {
        return when (viewType) {
            TYPE_WARM -> WarmWeatherViewHolder(
                ListItemWarmBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )
            TYPE_COLD -> ColdWeatherViewHolder(
                ListItemColdBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            )
            else -> throw IllegalStateException("unknown view type")
        }

    }

    override fun onBindViewHolder(holder: WeatherViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    abstract class WeatherViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        abstract fun bind(data: ListElement)
    }

    class WarmWeatherViewHolder(private val binding: ListItemWarmBinding) :
        WeatherViewHolder(binding.root) {
        override fun bind(data: ListElement) {
            binding.tvDate.text = data.dtTxt
            binding.tvTemp.text = "${data.main.temp} °C"
        }
    }

    class ColdWeatherViewHolder(private val binding: ListItemColdBinding) :
        WeatherViewHolder(binding.root) {
        override fun bind(data: ListElement) {
            binding.tvDate.text = data.dtTxt
            binding.tvTemp.text = "${data.main.temp} °C"

            binding.imgCloud.visibility = if (data.clouds.all > 50) View.VISIBLE else View.GONE
        }
    }
}